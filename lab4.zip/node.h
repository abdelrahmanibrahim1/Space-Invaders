/*Abd Elrahman Ibrahim*/

typedef struct Node {
	struct Node *next;
	void *data;
} Node;
