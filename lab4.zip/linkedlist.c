/*Abd Elrahman Ibrahim*/

#include <stdio.h>
#include <stdlib.h>

#include "altmem.h"
#include "debug.h"
#include "node.h"
#include "linkedlist.h"

#define true 1

/*Helper functions*/

/*Returns true if a pointer isn't null*/
static int ptrNotNull(Node *ptr) {
	return ptr != NULL;
}

/*This function creates a node*/
static void *createNode() {
	static int count;
	void *ptr = alternative_malloc(sizeof(Node));
	if (ptr != NULL) {
		count++;
		if (TEXT) printf("DIAGNOSTIC: %d nodes allocated\n", count);
	}
	return ptr;
}

/*This function recycles a node*/
static void recycleNode(void *node) {
	static int count;
	alternative_free(node);
	node = NULL;
	count++;
	if (TEXT) printf("DIAGNOSTIC: %d nodes freed\n", count);
}

/*This function does terse insert*/
static void terseInsert(void *p2head, Node *p2input, ComparisonFunction goesInFrontOf) {
	Node **p2p2node = p2head;
	if (*p2p2node != NULL && !goesInFrontOf(p2input -> data, (*p2p2node) -> data)) {
		p2p2node = &((*p2p2node) -> next);	
	}
	p2input -> next = *p2p2node;
	*p2p2node = p2input;
}

/*Linked list code*/

/*This function iterates through the list doing the action defined by ActionFunction*/
void iterate (void *head, ActionFunction doThis) {
	Node *ptr = head;
	while (ptrNotNull(ptr)) {
		doThis(ptr -> data);
		ptr = ptr -> next;
	}
	if (DEBUG) printf("Successfully iterated through the list\n");
}

/*This function returns true if a node in the list satisfies the CriteriaFunciton, false otherwise*/
int any(void *head, CriteriaFunction yes, void *helper) {
	int result = 0;
	Node *ptr = head;
	while (ptrNotNull(ptr) && (result = yes(ptr -> data, helper)) == 0) {
		ptr = ptr -> next;					
	}
	if (DEBUG) printf("any: returned value is %d\n", result);
	return result;
}

/*This function inserts an alien into the linked list*/
int insert(void *p2head, void *data, ComparisonFunction goesInFrontOf, int text){
	void *ptr = createNode();
	Node *node = ptr;
	int result = 0;
	if (ptrNotNull(node)) {
		node -> data = data;
		terseInsert(p2head, node, goesInFrontOf);
		result = 1;
		if (DEBUG) printf("insert: Alien inserted.\n");
	} else {
		recycleNode(ptr);
	}
	return result;
}

/*This function deletes a node*/
int deleteSome(void *p2head, CriteriaFunction mustGo, void *helper, ActionFunction disposal, int text) {
	int numDeletes = 0;
	Node **p2p2node = p2head;
	Node *holder;
	while (ptrNotNull(*p2p2node)) {
		if (!mustGo((*p2p2node)->data, helper)) {
			p2p2node = &((*p2p2node) -> next);
		} else {
			numDeletes++;
			holder = *p2p2node;
			*p2p2node = holder -> next;
			recycleNode(holder);
			if (DEBUG) printf("deleteSome: node deleted\n");
		}
	}
	return numDeletes;
}

/*This function swaps the data in two nodes*/
static void performSwap(Node *currNode, Node *nextNode) {
	void *dataToSwap = currNode -> data;
	currNode -> data = nextNode -> data;
	nextNode -> data = dataToSwap;
}

/*This function sorts the linked list*/
void sort(void *head, ComparisonFunction goesInFrontOf) {
	Node *prevMax = NULL;
	Node *node = head;
	int insertedElements = 0;
	while (true) {
		while (node != NULL && node -> next != prevMax) {
			if (!goesInFrontOf(node -> data, node->next->data)) {
				performSwap(node, node->next);
				insertedElements = 1;
			}
			node = node -> next;
		}
		if (!insertedElements) break;
		prevMax = node;
		node = head;
		insertedElements = 0;
	}
}
