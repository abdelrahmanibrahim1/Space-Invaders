/*Abd Elrahman Ibrahim*/

int init() ;
int main(int argc, char *argv[]) ;
FILE *openInputStream(char *inputFile) ;
void outputLoop(struct Sim *sim) ;
void populateSim(struct Sim *sim, FILE *inputStream) ;
void putOnList(struct Sim *sim, void *dynamicAlien) ;
int readIntoAlien(struct Alien *ptr, struct Sim *sim) ;
void readLoop(FILE *inputStream) ;
void *readStaticToDynamic(struct Alien *statAlien) ;
void teardown(FILE *inputStream, char *inputFile) ;
int thereAreAliens(int num) ;
