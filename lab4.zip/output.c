/*Abd Elrahman Ibrahim*/

#include <stdio.h>
#include <math.h>

#include "structs.h"
#include "debug.h"
#include "output.h"
#include "code.h"
#include "motion.h"
#include "invaders.h"
#include "functions.h"
#include "linkedlist.h"
#include "memory.h"

#define repeatedCall 4.0

/*This function decides whether to output the alien graphically or textually */
void outputAlien(struct Sim *sim) {
	sort(sim -> list, sortAliens);	
	if (GRAPHICS) drawAlien(sim); 
	if (TEXT) printAlien(sim);
}

/*This method terminates the textual output*/
void terminate(int valFromReading) {
	printf("Input terminated: scanf returned %d", valFromReading);
}

/*This function checks if there are still aliens in the list*/
int aliensOnList(struct Sim *sim) {
	return (sim -> list == NULL) == 0;
}

/*This function checks if any aliens landed yet*/
int aliensInAir(struct Sim *sim) {
	return any(sim -> list, noAliensLanded, NULL) == 0;
}

/*This function deletes the aliens that are above the bolt and any flying saucers out of bounds*/
void fightBack(struct Sim *sim, JumpFunc *array) {
	if (TEXT) {
		deleteSome(&(sim -> list), shouldFightBack, NULL, deleteAlien, TEXT);
	} else {
		sim -> currChar = sa_getch();
		if (withinBounds(sim -> currChar) && allowableChar(sim -> currChar)) {
			array[sim -> currChar](sim);	
		}
	}
	deleteSome(&(sim -> list), alienIsSaucer, NULL, deleteSaucer, TEXT);
}

/*This function returns whether a character is allowed or not*/
int allowableChar(char currChar) {
	return currChar == 32 || currChar == 52 || currChar == 54;
}

/*This funcion returns whether a character is within bounds of the jumptable*/
int withinBounds(char currChar) {
	return currChar >= 0 && currChar <= 255;
}

/*This function updates the elapsed time*/
void updateElapsedTime(struct Sim *sim) {
	sim -> ET += sim -> deltaT;
}

/*This function outputs the total score and clears the list*/
void scoreAndSim(struct Sim *sim) {
	int result;
	printf("Total score is %d points\n", sim -> score);
	printf("Clearing the attacking list...\n");
	result = clearList(sim);
	printf("      ... %d cleared\n", result);
}

/*This function outputs victory messages*/
void victoryMessages(struct Sim *sim) {
	printf("\n\n");
	printf("Victory! No attackers remain at ET = %.5lf\n", sim -> ET);
}

/*This function outputs the necessary textual output depending on whether the aliens won or we won*/
void determineVictoryOrDefeat(struct Sim *sim) {
	if (!aliensOnList(sim)) {
		victoryMessages(sim);
	} else {
		outputHeader(sim -> ET);		
		iterate(sim -> list, outputTable);
		printf("\n\n");
		printf("Defeat! Aliens land at ET = %.5lf\n", sim -> ET);
	}
	scoreAndSim(sim);
}

/*This function outputs information about the alien's descent textually*/
void printAlien(struct Sim *sim) {	
	while (aliensOnList(sim) && aliensInAir(sim)) {
		if (needTableOrDrawing(sim)) {
			outputHeader(sim -> ET);
			iterate(sim -> list, outputTable);
			printf("\n");
		}
		updateElapsedTime(sim);
		iterate(sim -> list, updateMotion);
		fightBack(sim, NULL);
		sort(sim -> list, sortAliens);
	}
	determineVictoryOrDefeat(sim);
}

/*This function checks if you need to output a table or output a bolt*/
int needTableOrDrawing(struct Sim *sim) {
	return (sim -> ET == 0.0 || (int) (sim -> ET) - (int) (sim -> ET - sim -> deltaT)); 
}
/*This function returns the header for the table in textual output*/
void outputHeader(double ET) {
	printf("\nCode       T C Pts ( __X_____, __Y_____) ( __VX____, __VY____) ET=  %.5lf\n", ET);
}

/*This function draws the base and the bolt*/
void drawBaseAndBolt(struct Sim *sim) {
	sa_base(sim -> X);
	if (sim -> currChar == 32) {
		sa_bolt(sim -> X);
	}
}

/*This function refreshes the simulation and sleeps*/
void refreshAndSleep(struct Sim *sim) {
	sa_time((int) (sim -> ET * 1000));
	sa_refresh();
	microsleep((unsigned int) (sim -> deltaT * 1000000));
}

/*This function outputs aliens in their current state*/
void createOutput(struct Sim *sim) {
	iterate(sim -> list, outputAllAliens);
	sa_score(sim -> score);
	refreshAndSleep(sim);
}

/*This function updates the aliens*/
void updateMotionAndAliens(struct Sim *sim, JumpFunc *jumpTable) {
	iterate(sim -> list, updateMotion);
	fightBack(sim, jumpTable);
}

/*This function fires a bolt*/
void fireBolt(struct Sim *sim) {
	deleteSome(&(sim -> list), aboveBase, NULL, deleteAlien, TEXT);
}

/*This function moves the base 1 unit to the left*/
void sub1(struct Sim *sim) {
	if (sim -> X >= -39.0) {
		sim -> X -= 1;
	}
}

/*This function moves the base 1 unit to the right*/
void add1(struct Sim *sim) {
	if (sim -> X <= 39.0) {
		sim -> X += 1;
	}
}

/*This function initializes the jump table*/
void createJumpTable(JumpFunc *result) {
	result[32] = fireBolt;
	result[52] = sub1;
	result[54] = add1;
}

/*This function performs the necessary graphical output for the aliens*/
void drawAlien(struct Sim *sim) {
	JumpFunc jumpTable[256];
	createJumpTable(jumpTable);
	sa_clear();
	drawBaseAndBolt(sim);
	createOutput(sim);
	while (aliensOnList(sim) && aliensInAir(sim)) {
		loopBody(sim, jumpTable);
	}
	repeatCall(sim);
}

/*This function performs the body of teh while loop for drawAlien*/
void loopBody(struct Sim *sim, JumpFunc *jumpTable) {
	updateElapsedTime(sim);
	updateMotionAndAliens(sim, jumpTable);
	sa_clear();
	drawBaseAndBolt(sim);
	createOutput(sim);
}

/*This function causes the same graphical output to be outputted for 4 seconds*/
void repeatCall(struct Sim *sim) {
	double startTime = now();
	while (now() - startTime < repeatedCall) {
		sa_clear();
		sa_base(0.0);
		createOutput(sim);
	}
}
