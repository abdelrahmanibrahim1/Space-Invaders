/*Abd Elrahman Ibrahim*/

typedef void (*JumpFunc) (struct Sim *sim);
