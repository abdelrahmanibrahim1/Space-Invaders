/*Abd Elrahman Ibrahim*/
int aboveBase(void *data, void *helper) ;
int alienIsSaucer(void *data, void *helper) ;
int clearList(struct Sim *sim) ;
int clearingList(void *data, void *helper) ;
void deleteAlien(void *data) ;
void deleteSaucer(void *data) ;
int noAliensLanded(void *data, void *helper) ;
void outputAllAliens(void *data) ;
void outputTable(void *data) ;
int shouldFightBack(void *data, void *helper) ;
int sortAliens(void *data1, void *data2) ;
void updateMotion(void *data) ;
