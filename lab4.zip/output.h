/*Abd Elrahman Ibrahim*/

#include "jumptable.h"
void add1(struct Sim *sim) ;
int aliensInAir(struct Sim *sim) ;
int aliensOnList(struct Sim *sim) ;
int allowableChar(char currChar) ;
void createJumpTable(JumpFunc *result) ;
void createOutput(struct Sim *sim) ;
void determineVictoryOrDefeat(struct Sim *sim) ;
void drawAlien(struct Sim *sim) ;
void drawBaseAndBolt(struct Sim *sim) ;
void fightBack(struct Sim *sim, JumpFunc *array) ;
void fireBolt(struct Sim *sim) ;
void loopBody(struct Sim *sim, JumpFunc *jumpTable) ;
int needTableOrDrawing(struct Sim *sim) ;
void outputAlien(struct Sim *sim) ;
void outputHeader(double ET) ;
void printAlien(struct Sim *sim) ;
void refreshAndSleep(struct Sim *sim) ;
void repeatCall(struct Sim *sim) ;
void scoreAndSim(struct Sim *sim) ;
void sub1(struct Sim *sim) ;
void terminate(int valFromReading) ;
void updateElapsedTime(struct Sim *sim) ;
void updateMotionAndAliens(struct Sim *sim, JumpFunc *jumpTable) ;
void victoryMessages(struct Sim *sim) ;
int withinBounds(char currChar) ;
