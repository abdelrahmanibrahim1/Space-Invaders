/*Abd Elrahman Ibrahim*/

#include <stdio.h>
#include "ProFunctionPointers.h"
#define EXIT_SUCCESS 0

void printTesting() {
	printf("Testing to see if I can change function pointers...\n");
}

void printCodeWorked() {
	printf("Successfully changed function pointer!\n");
}

int main() {
	void (*ptr)() = printTesting;
	ptr();
	ptr = printCodeWorked;
	ptr();
	return EXIT_SUCCESS;
}
