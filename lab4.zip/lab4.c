/*Abd Elrahman Ibrahim*/

#include <stdio.h>

#include "structs.h"
#include "code.h"
#include "lab4.h"
#include "memory.h"
#include "debug.h"
#include "functions.h"
#include "linkedlist.h"
#include "invaders.h"
#include "output.h"

#define REQUIRED_INPUTS 5
#define EXIT_SUCCESS 0
#define CHANGE_T 0.03125

/*This function reads into the alien the input provided and also adds the definition of the color, type, and point value of an alien*/
int readIntoAlien(struct Alien *ptr, struct Sim *sim) {
	return readInput(&(ptr -> Code), &(ptr -> X), &(ptr -> Y), &(ptr -> VX), &(ptr -> VY), sim);
}

/*Reads an alien in static memory and sends the data over to dynamic memory*/
void *readStaticToDynamic(struct Alien *statAlien) {
	void *alien = dynamicAlloc(sizeof(struct Alien));
	if (alien != NULL) {
		transferStatToDynamic(statAlien, alien);
	}
	return alien;
}

/*Initializes the Sim struct*/
void populateSim(struct Sim *sim, FILE *inputStream) {
	sim -> ET = 0.0;
	sim -> list = NULL;
	sim -> X = 0.0;
	sim -> score = 0;
	sim -> deltaT = CHANGE_T;
	sim -> input = inputStream;
	sim -> output = stdout;
}

/*This function checks if another alien is provided in the input file*/
int thereAreAliens(int num) {
	return REQUIRED_INPUTS == num;
}

/*This function puts an alien on alien on a list and deals with failure*/
void putOnList(struct Sim *sim, void *dynamicAlien) {
	if (!insert(&(sim -> list), dynamicAlien, sortAliens, TEXT)) {
		freeAlien(dynamicAlien);
	}
}

/*This is the main sim loop that controls populating the alien list and output*/
void readLoop(FILE *inputStream) {
	struct Alien statAlien;
	void *dynamicAlien;
	struct Sim sim;
	int items;
	populateSim(&sim, inputStream);
	statAlien.sim = &sim;
	items = readIntoAlien(&statAlien, &sim);
	while (thereAreAliens(items)) {
		dynamicAlien = readStaticToDynamic(&statAlien);
		if (dynamicAlien != NULL) {
			putOnList(&sim, dynamicAlien);
		}
		items = readIntoAlien(&statAlien, &sim);
	}
	if (TEXT) printf("Input terminated: scanf returned %d\n", items);
	outputLoop(&sim);
}

/*By Prof. Neil Kirby*/
int init() {
	return (TEXT || ( GRAPHICS && sa_initialize()));
}

/*By Prof. Neil Kirby*/
void teardown(FILE *inputStream, char *inputFile) {
	fclose(inputStream);
	if (TEXT) printf("DIAGNOSTIC: Closed input file %s.\n", inputFile);
	if (GRAPHICS) sa_teardown();
}

/*This function handles all of the output necessary*/
void outputLoop(struct Sim *sim) {
	outputAlien(sim);
}

/*This function open the input stream*/
FILE *openInputStream(char *inputFile) {
	FILE *result = fopen(inputFile, "r");
	if (result != NULL && TEXT) {
		printf("DIAGNOSTIC: Successfully opened %s for input.\n", inputFile);
	} else if (TEXT){
		printf("ERROR: Unable to open %s for input.\n", inputFile);
	}
	return result;
}

/*Main method by Prof. Neil Kirby*/
/*I modified the last line to return EXIT_SUCCESS instead of 0*/
int main(int argc, char *argv[]) {
	double start, runtime;
	FILE *inputStream;
	if (argc > 1) {
		start = now();
		if ((inputStream = openInputStream(argv[1])) != NULL && init()) {
			readLoop(inputStream);
			teardown(inputStream, argv[1]);
		}

		runtime = now() - start;
		printf("Total run time is %.9lf seconds.\n", runtime);
	}


	return (EXIT_SUCCESS);
}
