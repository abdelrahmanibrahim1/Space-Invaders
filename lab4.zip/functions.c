/*Abd Elrahman Ibrahim*/

#include <stdio.h>

#include "structs.h"
#include "motion.h"
#include "memory.h"
#include "debug.h"
#include "linkedlist.h"
#include "invaders.h"

#define NO_SAUCER 0
#define FOUND_SAUCER 1
#define SAUCER 3
#define BOMB 4

/*CRITERIA FUNCTIONS*/
/*This function checks if an alien is on the ground*/
int noAliensLanded(void *data, void *helper) {
	struct Alien *alien = data;
	return alien -> Y == 0;
}

/*This function determines whether the bolt hits any of the aliens*/
int shouldFightBack(void *data, void *helper) {
	struct Alien *alien = data;
	/*Checks if an alien lies above the bolt and ET isn't 0*/
	if (alien -> sim -> ET != 0.0 && (int) (alien -> sim -> ET) - (int) (alien -> sim -> ET - alien -> sim -> deltaT)) {
		return (int) (alien -> X) == (int)(alien -> sim -> X);
	}
	return 0;
}

/*Checks if an alien is a flying saucer that passed the left or right edge*/
int alienIsSaucer(void *data, void *helper) {
	struct Alien *alien = data;
	if ((alien -> Type == SAUCER) && outOfBounds(alien)) {
		return FOUND_SAUCER;
	}
	return NO_SAUCER;
}

/*This function always return true to always delete elements in the list when clearing it*/
int clearingList(void *data, void *helper) {
	return 1;
}

/*This function determines if an alien is above the base*/
int aboveBase(void *data, void *helper) {
	struct Alien *alien = data;
	return (int)alien -> X == (int)alien -> sim -> X;
}

/*COMPARISON FUNCTIONS*/
/*This function sorts aliens according to their altitude*/
int sortAliens(void *data1, void *data2) {
	struct Alien *alien1 = data1;
	struct Alien *alien2 = data2;
	return (alien1 -> Y) >= (alien2 -> Y);
}

/*ACTION FUNCTIONS*/
/*This function create the tabular output for the aliens*/
void outputTable(void *data) {
	struct Alien *alien = data;
	printf("0x%08X %d %d %3d (%9.5lf,%9.5lf) (%9.5lf,%9.5lf)\n", alien -> Code, alien -> Type, alien -> Color, alien -> Points, alien -> X, alien -> Y, alien -> VX, alien ->VY);
}

/*This function deletes a flying saucer*/
void deleteSaucer(void *data) {
	struct Alien *alien = data;
	if (TEXT) printf("Flying saucer worth %d points escapes at ET = %.5lf!\n", alien -> Points, alien -> sim -> ET);
	if (GRAPHICS) sa_status("Flying saucer escapes!");
	freeAlien(data);
}

/*This function deletes an alien*/
void deleteAlien(void *data) {
	struct Alien *alien = data;
	alien -> sim -> score += alien -> Points;
	if (TEXT) printf("Bolt hits alien at (%.5lf, %.5lf), scores %d points!\n", alien -> X, alien -> Y,  alien -> Points);
	if (GRAPHICS) sa_status("Bolt hits an alien!");
	freeAlien(data);
}

/*This function updates motion for the aliens*/
void updateMotion(void *data) {
	struct Alien *alien = data;
	if (alien -> Type == SAUCER || alien -> Type == BOMB) {
		updateX(alien);
		updateY(alien);
	} else {
		updateX(alien);
		updateY(alien);
		updateVX(alien);
	}
}

/*This function outputs all of the aliens on the list graphically*/
void outputAllAliens(void *data) {
	struct Alien *alien = data;
	sa_alien(alien -> Type, alien -> Color, alien -> X, alien -> Y);
}


/*OTHER FUNCTIONS*/
/*This function clears the list when output is completed*/
int clearList(struct Sim *sim) {
	return deleteSome(&(sim -> list), clearingList, NULL, freeAlien, TEXT);
}
