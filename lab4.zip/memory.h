/*Abd Elrahman Ibrahim*/

void *dynamicAlloc(int size) ;
void freeAlien(void *alien) ;
void transferStatToDynamic(struct Alien *statAlien, void *ptr) ;
