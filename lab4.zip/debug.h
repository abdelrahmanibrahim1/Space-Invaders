/*Abd Elrahman Ibrahim*/

/*this file is mandatory so we can run 3 ways:
 *GRAPHICS set to 1 - supresses ALL text output, draws instead.
 *GRAPHICS set to 0 - text mode, VERBOSE controls what prints.
 *TEXT has 2 modes:
 *VERBOSE to 1 to get DEBUG output
 *VERBOSE to 0 to get only the required text output
 *Do not set TEXT or DEBUG directly; change GRAPHICS and VERBOSE instead.
 */

#define VERBOSE 0
#define TEXT (! GRAPHICS)
#define GRAPHICS 0  

#define DEBUG (VERBOSE && TEXT)
