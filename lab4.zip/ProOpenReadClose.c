/*Abd Elrahman Ibrahim*/

#include <stdio.h>

/*This function opens the stream*/
FILE *openStream(char *fileName) {
	return fopen(fileName, "r");
}

/*This function closes the stream*/
int closeStream(FILE *stream) {
	return fclose(stream);
}

void readFromFile(FILE *stream) {
	unsigned int code;
	double num1, num2, num3, num4;
	fscanf(stream, "%x %lf %lf %lf %lf", &code, &num1, &num2, &num3, &num4);
	printf("code is %x, num1 is %lf, num2 is %lf, num3 is %lf, num4 is %lf.", code, num1, num2, num3, num4);  
}

/*Main function*/
int main(int argc, char **argv) {
	FILE *inputStream = openStream(argv[1]);
	readFromFile(inputStream);
	closeStream(inputStream);
	return 0;
}


