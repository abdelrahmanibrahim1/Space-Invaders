
/*Abd Elrahman Ibrahim*/

#include <stdio.h>

#include "structs.h"
#include "motion.h"
#include "debug.h"

#define RIGHTEDGE 39.0
#define LEFTEDGE -39.0
#define GROUND 0.0

/*Checks if alien is out of bounds*/
int outOfBounds(struct Alien *alien) {
	return (alien -> X >= RIGHTEDGE && alien -> VX > 0.0) || (alien -> X <= LEFTEDGE && alien -> VX < 0.0);
}

/*This function updates the value of VX*/
void updateVX(struct Alien *alien) {
	if (outOfBounds(alien)) {
		alien -> VX = -(alien -> VX); 
		reduceY(alien);
	}
}

/*This function reduces an alien's Y value by 3*/
void reduceY(struct Alien *alien) {
	alien -> Y -= 3;
	if (alien -> Y <= GROUND) {
		alien -> Y = GROUND;
		if (TEXT) printf("\nAlien %08X touches down at %+lf!\n", alien -> Code, alien -> X);
	} else {
		if (TEXT) printf("\nAlien 0x%08X drops to (%lf, %lf), VX to %+lf at ET %.5lf\n", alien -> Code, alien -> X, alien -> Y, alien -> VX, alien -> sim -> ET);
	}
}

/*This function updates the value of X*/
void updateX(struct Alien *alien) {
	alien -> X = alien -> X + (alien -> VX) * alien -> sim -> deltaT;
}

/*This function updates the value of y*/
void updateY(struct Alien *alien) {
	double newY = alien -> Y + alien -> VY * alien -> sim -> deltaT;
	if (newY <= GROUND) {
		newY = GROUND;
		if (TEXT) printf("\nAlien 0x%08X touches down at %+lf!\n", alien -> Code, alien -> X);
	}
	alien -> Y = newY;
}
