/*Abd Elrahman Ibrahim*/


int compareStrings(void *data1, void *data2) ;
void deleteString(void *data) ;
int main() ;
int mustGo(void *data, void *helper) ;
void printString(void *data) ;
