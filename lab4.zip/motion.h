/*Abd Elrahman Ibrahim*/

int outOfBounds(struct Alien *alien) ;
void reduceY(struct Alien *alien) ;
void updateVX(struct Alien *alien) ;
void updateX(struct Alien *alien) ;
void updateY(struct Alien *alien) ;
