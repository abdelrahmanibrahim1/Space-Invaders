/*Abd Elrahman Ibrahim*/

struct Sim {
	double ET;
	void *list;
	double X; 
	int score;
	double deltaT;
	FILE *input;
	FILE *output;
	int currChar;
};	

struct Alien {
	unsigned int Code;
	double X;
	double Y;
	double VX;
	double VY;
	int Color;
	int Type;
	int Points;
	struct Sim *sim;
};

