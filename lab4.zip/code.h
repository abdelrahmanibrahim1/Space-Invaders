/*Abd Elrahman Ibrahim*/

int bitSolver(unsigned int code, int numShifts, int numBits) ;
int color(unsigned int code) ;
void getAccurateDesiredNum(int *numBits, int *desiredNum) ;
int pointValue(unsigned int code) ;
void populateAlien(struct Alien *alien, unsigned int Code) ;
int readInput(unsigned int *code, double *X, double *Y, double *VX, double *VY, struct Sim *sim) ;
int type (unsigned int code) ;
