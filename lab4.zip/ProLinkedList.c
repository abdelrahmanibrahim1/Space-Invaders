/*Abd Elrahman Ibrahim*/

#include <stdio.h>
#include "string.h"
#include "linkedlist.h"
#include "debug.h"
#include "ctype.h"

int compareStrings(void *data1, void *data2) {
	char *str1 = data1;
	char *str2 = data2;
	return strcmp(str2, str1);
}

void printString(void *data) {
	char *ptr = data;
	printf("The inputted string is %s.\n", ptr);
}

int mustGo(void *data, void *helper) {
	char *ptr = data;
	return islower(ptr[0]);
}

void deleteString(void *data) {
	data = NULL;	
}

int main() {
	void *list;
	insert(&list, "abdelrahman", compareStrings, TEXT);
	insert(&list, "Ibrahim", compareStrings, TEXT);
	insert(&list, "Right", compareStrings, TEXT);
	insert(&list, "wrong", compareStrings, TEXT);
	iterate(list, printString);
	while (any(list, mustGo, NULL)) {
		deleteSome(&list, mustGo, NULL, deleteString, TEXT); 
	}
	iterate(list, printString);
	return 0;
}
