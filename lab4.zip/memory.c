/*Abd Elrahman Ibrahim*/

#include <stdlib.h>
#include <stdio.h>

#include "altmem.h"
#include "structs.h"
#include "debug.h"
#include "code.h"
#include "memory.h"

/*This function allocates dynamic memory for the alien*/
void *dynamicAlloc(int size) {
	static int count;
	void *ptr = alternative_malloc(size);
	if (ptr != NULL) {
		count++; 
		if (TEXT) printf("dynamicAlloc: %d allocated\n", count);
	} else {
		if (TEXT) printf("ERROR: dynamicAlloc: failed to allocate:\n");
	}
	return ptr;
}

/*This function frees the dynamic memory in which an alien is stored in*/
void freeAlien(void *alien) {
	static int count;
	alternative_free(alien);
	alien = NULL;
	count++;
	if (TEXT) printf("freeAlien: %d freed\n", count);
}

/*This function transfers a statically allocated alien to a dynamically allocated alien*/
void transferStatToDynamic(struct Alien *statAlien, void *ptr) {
	struct Alien *dynamicAlien = ptr;
	dynamicAlien -> Code = statAlien -> Code;
	dynamicAlien -> X = statAlien -> X;
	dynamicAlien -> Y = statAlien -> Y;
	dynamicAlien -> VX = statAlien -> VX;
	dynamicAlien -> VY = statAlien -> VY;
	dynamicAlien -> sim = statAlien -> sim;
	populateAlien(dynamicAlien, dynamicAlien -> Code);
}

