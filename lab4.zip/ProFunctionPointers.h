/*Abd Elrahman Ibrahim*/


int main() ;
void printCodeWorked() ;
void printTesting() ;
