
/*Abd Elrahman Ibrahim*/

#include <stdio.h>

#include "structs.h"
#include "code.h"
#include "debug.h"

#define COLOR_SHIFT 4
#define TYPE_SHIFT 12
#define POINTS_SHIFT 20

#define COLOR_BITS 3
#define TYPE_BITS 3
#define POINTS_BITS 9

/*This function reads from an input file values related to the alien*/
int readInput(unsigned int *code, double *X, double *Y, double *VX, double *VY, struct Sim *sim) {
	return fscanf(sim -> input, "%x %lf %lf %lf %lf", code, X, Y, VX, VY);
}

/*Returns the color of the alien*/
int color(unsigned int code) {  
	if (DEBUG) printf("color: color of alien is %d\n", bitSolver(code, 4, 3)); 
	return bitSolver(code, COLOR_SHIFT, COLOR_BITS); 
}

/*Returns the type of the alien*/
int type (unsigned int code) {
	if (DEBUG) printf("type: type of alien is %d\n", bitSolver(code, 12, 3));
	return bitSolver(code, TYPE_SHIFT, TYPE_BITS);
}

/*Returns the point value*/
int pointValue(unsigned int code) {
	if (DEBUG) printf("pointValue: pointValue of alien is %d\n", bitSolver(code, 20, 9));
	return bitSolver(code, POINTS_SHIFT, POINTS_BITS);
}

/*Returns an accurate value for desiredNum*/
void getAccurateDesiredNum(int *numBits, int *desiredNum) {
	while (*numBits) {
		*desiredNum *= 2;
		(*numBits)--;
	}
	(*desiredNum)--;
}

/*Evaluates the desired bits in the code*/
int bitSolver(unsigned int code, int numShifts, int numBits) {
	unsigned int result = code >> numShifts;
	int desiredNum = 1;
	getAccurateDesiredNum(&numBits, &desiredNum);
	return desiredNum & result;
}

/*This function populates a struct with an alien's color, type, and point value*/
void populateAlien(struct Alien *alien, unsigned int Code) {
	alien -> Color = color(Code);
	alien -> Type = type(Code);
	alien -> Points = pointValue(Code);
}


