/*Abd Elrahman Ibrahim*/

#include <stdio.h>

int main() {
	char arr[12] = "abdelrahman";
	printf("Entered string is %s\n", arr);
	arr[0] = 't';
	printf("Entered string is %s\n", arr);
	return 0;
}
